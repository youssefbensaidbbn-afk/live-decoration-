LIVE EDGE FURNITURE — WEBSITE PREVIEW

OPEN THE WEBSITE
1. Open index.html in a modern browser (Chrome, Edge, Firefox or Safari).
2. The product catalogue, search, category filter, sort, product details, language selector, responsive navigation and smooth scrolling work in the browser.
3. An internet connection is needed for the remote Unsplash photographs and Google Fonts.

LIGHT RAYS + SMOOTH SCROLL
- The page includes a built-in animated canvas LightRays effect inspired by the supplied settings: top-centre origin, cyan tint (#7FE3FF), gentle movement, haze and subtle mouse influence.
- Section links use a long eased scroll animation. Mouse-wheel scrolling has additional easing. Touch and keyboard navigation remain native. Reduced-motion preferences are respected.

BEFORE PUBLISHING
- Edit the CONFIG object near the start of the JavaScript in index.html.
  businessEmail: replace YOUR_EMAIL_HERE with the real business email.
  whatsappNumber: replace 216XXXXXXXX with the real WhatsApp number (international format, digits only).
- Product names, prices, dimensions, weights, production estimates and availability are EXAMPLE / DEMO CONTENT. Confirm every item with the business before publication.
- Images are editorial inspiration from Unsplash and are not verified photographs of the actual products.

IMPORTANT LIMITATIONS
This deliverable is a working standalone front-end catalogue, not a production full-stack platform. It does not include a connected database, administrator dashboard, login/MFA, persistent inquiry backend, server-side email delivery, secure file storage, or completed legal policies. The inquiry form prepares an email draft when a real email address is configured; without one it copies the inquiry text where browser permissions allow. No payment, checkout, shopping cart or customer account functionality is present.

For production, connect a server-side backend and database, add server-side validation and authorization, configure transactional email and secure uploads, write jurisdiction-specific privacy/terms/cookie notices, and run security testing before launch.
