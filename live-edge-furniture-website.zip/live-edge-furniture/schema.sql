-- Suggested PostgreSQL starting schema for a future production backend.
-- This file is documentation only; index.html does not connect to this database.
CREATE TABLE categories (
  id BIGSERIAL PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name_en TEXT NOT NULL,
  name_fr TEXT,
  name_ar TEXT,
  description TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE products (
  id BIGSERIAL PRIMARY KEY,
  sku TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  category_id BIGINT REFERENCES categories(id) ON DELETE SET NULL,
  name_en TEXT NOT NULL,
  name_fr TEXT,
  name_ar TEXT,
  short_description TEXT,
  description TEXT,
  price_tnd NUMERIC(12,3) NOT NULL CHECK (price_tnd >= 750),
  dimensions TEXT,
  wood_species TEXT,
  materials TEXT,
  finish TEXT,
  weight_kg NUMERIC(10,2),
  production_time TEXT,
  availability_status TEXT NOT NULL DEFAULT 'unconfirmed',
  is_published BOOLEAN NOT NULL DEFAULT false,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE product_images (
  id BIGSERIAL PRIMARY KEY,
  product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  storage_key TEXT NOT NULL,
  alt_text TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_primary BOOLEAN NOT NULL DEFAULT false
);

CREATE TABLE inquiries (
  id BIGSERIAL PRIMARY KEY,
  product_id BIGINT REFERENCES products(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT,
  subject TEXT,
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','contacted','completed')),
  internal_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX inquiries_status_created_idx ON inquiries(status, created_at DESC);
CREATE INDEX products_category_published_idx ON products(category_id, is_published);
